"""Small NumPy block-dictionary estimator; not the paper's BSF implementation.

Used only for calibration, never inference. For scale use a GPU-trained BSF.
"""
import numpy as np

def top_blocks(z, groups, width, active):
    """Keep whole blocks, including signed coordinates within retained blocks."""
    if not 1 <= active <= groups:
        raise ValueError('active must lie in [1, groups]')
    blocks = z.reshape(groups, width, -1)
    norms = np.linalg.norm(blocks, axis=1)
    selected = np.argpartition(norms, groups-active, axis=0)[groups-active:]
    mask = np.zeros_like(norms, dtype=bool)
    np.put_along_axis(mask, selected, True, axis=0)
    return (blocks * mask[:, None, :]).reshape(z.shape)


class BlockDictionary:
    """Alternating dictionary learning with iterative block hard thresholding.

    Nonconvex; neither global optimality nor semantic concept recovery is assured.
    Training mean is stored. Dictionary is calibration-only, never deployed.
    """
    def __init__(self, groups=12, width=3, active=2, seed=0):
        if groups < 1 or width < 1 or not 1 <= active <= groups:
            raise ValueError('invalid block dimensions or activity')
        self.groups, self.width, self.active, self.seed = groups, width, active, seed

    def encode(self, h, steps=35):
        x = h - self.mean
        z = np.zeros((self.groups*self.width, h.shape[1]))
        # Step 2a: iterative sparse coding. Faster: amortized BSF encoder on GPU,
        # warm starts, cached D.T@D, or batched group proximal optimization.
        step = 1.0 / max(np.linalg.norm(self.dictionary, 2)**2, 1e-12)
        for _ in range(steps):
            z = top_blocks(z + step*self.dictionary.T@(x-self.dictionary@z),
                           self.groups, self.width, self.active)
        return z

    def fit(self, h, iterations=20, *, progress=None):
        if h.ndim != 2 or h.shape[1] < 2 or not np.isfinite(h).all():
            raise ValueError('H must be a finite matrix with at least two samples')
        rng = np.random.default_rng(self.seed)
        self.mean = h.mean(axis=1, keepdims=True)
        x = h-self.mean
        self.dictionary = rng.normal(size=(h.shape[0], self.groups*self.width))
        self._normalize()
        energy = float(np.square(x).sum()) if progress is not None else None
        self.fit_diagnostics = {"iterations": iterations, "sparse_coding_steps": 35,
                                "stopping_rule": "fixed_iteration_budget"}
        for iteration in range(iterations):
            z = self.encode(h)
            # Step 2b: ridge dictionary update. Faster: minibatch sufficient
            # statistics and Cholesky solves; better recovery: restarts, dead-block
            # resampling, validation early stopping, or the paper's trained BSF.
            gram = z@z.T
            ridge = 1e-5*max(np.trace(gram)/len(gram), 1e-12)
            cross = z@x.T
            previous = self.dictionary
            self.dictionary = np.linalg.solve(gram+ridge*np.eye(len(gram)), cross).T
            self._normalize()
            if progress is not None:
                # Sufficient statistics avoid reconstructing the large sample
                # matrix. These are post-update losses with the current codes
                # held fixed, not a monotonic or convergence guarantee.
                error = max(0., energy-2*float((self.dictionary*cross.T).sum())
                            +float(((self.dictionary.T@self.dictionary)*gram.T).sum()))
                metrics = {"event": "dictionary_iteration", "iteration": iteration+1,
                    "iterations_total": iterations, "fit_samples": h.shape[1],
                    "features": h.shape[0], "sparse_coding_steps": 35,
                    "fixed_codes_relative_squared_error": error/max(energy, 1e-30),
                    "relative_dictionary_change": float(np.linalg.norm(self.dictionary-previous)
                        /max(np.linalg.norm(previous), 1e-30)), "ridge": float(ridge)}
                self.fit_diagnostics.update(metrics)
                progress(metrics)
        return self

    def _normalize(self):
        for g in range(self.groups):
            sl = slice(g*self.width, (g+1)*self.width)
            block = self.dictionary[:, sl]
            block /= max(np.linalg.norm(block, 2), 1e-12)

    def encode_support(self, h, steps=35):
        """Boolean active-block mask ``[groups, samples]`` from sparse codes."""
        z = self.encode(h, steps=steps).reshape(self.groups, self.width, -1)
        return np.linalg.norm(z, axis=1) > 1e-8

    def factor_state(self, h, neighbors=16, rank=1, seed=1, steps=35):
        """Per-factor ambient tangent bases and per-sample encode support.

        Unlike ``tangents()``, bases stay labeled by factor (not pooled probes).
        Local PCA reuses the same block-code neighborhood chart construction;
        degenerate blocks fall back to the leading dictionary columns.

        Returns
        -------
        bases : ndarray, shape ``[d, groups, rank]``
        active : ndarray, shape ``[groups, samples]``, bool
        """
        if not 1 <= rank <= self.width or neighbors < 2:
            raise ValueError('invalid tangent estimation settings')
        z = self.encode(h, steps=steps).reshape(self.groups, self.width, -1)
        active = np.linalg.norm(z, axis=1) > 1e-8
        bases = np.zeros((h.shape[0], self.groups, rank), dtype=np.float64)
        rng = np.random.default_rng(seed)
        for g in range(self.groups):
            block = self.dictionary[:, g * self.width:(g + 1) * self.width]
            codes = z[g][:, active[g]]
            directions = None
            if codes.shape[1] >= max(3, rank + 1):
                ambient = block @ codes
                # One neighborhood chart around a random active code (same local
                # PCA as tangents(); keep a single labeled basis per factor).
                anchor = int(rng.integers(codes.shape[1]))
                dist = np.sum((ambient - ambient[:, anchor:anchor + 1]) ** 2, axis=0)
                ix = np.argsort(dist)[:min(neighbors, codes.shape[1])]
                local = codes[:, ix] - codes[:, ix].mean(axis=1, keepdims=True)
                u, s, _ = np.linalg.svd(local, full_matrices=False)
                keep = min(rank, int(np.sum(s > 1e-10)))
                if keep:
                    directions = block @ u[:, :keep]
            if directions is None or directions.shape[1] == 0:
                # Factor span fallback when the local chart is empty/degenerate.
                q, _ = np.linalg.qr(block)
                bases[:, g, :] = q[:, :rank]
                continue
            q, sv, _ = np.linalg.svd(directions, full_matrices=False)
            keep = min(rank, int(np.sum(sv > 1e-10)))
            if keep == 0:
                q, _ = np.linalg.qr(block)
                bases[:, g, :] = q[:, :rank]
            else:
                bases[:, g, :keep] = q[:, :keep]
                if keep < rank:
                    # Pad remaining columns from the dictionary block orthocomplement.
                    q_block, _ = np.linalg.qr(block)
                    bases[:, g, keep:] = q_block[:, keep:rank]
        return bases, active

    def tangents(self, h, neighbors=16, anchors=10, rank=1, seed=1):
        """Local PCA in each active block, mapped back to ambient coordinates.

        Pooling concept-wise tangents approximates an additive manifold model.
        It does not model interactions, support transitions, or joint curvature.
        Prefer ``factor_state`` when bases must stay labeled by concept factor.
        """
        if not 1 <= rank <= self.width or neighbors < 2 or anchors < 1:
            raise ValueError('invalid tangent estimation settings')
        z = self.encode(h).reshape(self.groups, self.width, -1)
        rng = np.random.default_rng(seed)
        probes = []
        # Step 3: local charts. Faster: approximate nearest-neighbor indices per
        # block, randomized PCA, and batched GPU SVD. Better: adaptive rank/radius,
        # sample-density weighting, and joint-chart estimates for coactive blocks.
        for g in range(self.groups):
            codes = z[g][:, np.linalg.norm(z[g], axis=0) > 1e-8]
            if codes.shape[1] < max(3, rank+1):
                continue
            basis = self.dictionary[:, g*self.width:(g+1)*self.width]
            ambient = basis@codes
            for anchor in rng.choice(codes.shape[1], min(anchors, codes.shape[1]), replace=False):
                dist = np.sum((ambient-ambient[:, anchor:anchor+1])**2, axis=0)
                ix = np.argsort(dist)[:min(neighbors, len(dist))]
                local = codes[:, ix]-codes[:, ix].mean(axis=1, keepdims=True)
                u, s, _ = np.linalg.svd(local, full_matrices=False)
                directions = basis@u[:, :min(rank, int(np.sum(s > 1e-10))) ]
                if directions.shape[1]:
                    # SVD avoids inventing tangent directions for degenerate blocks.
                    q, sv, _ = np.linalg.svd(directions, full_matrices=False)
                    probes.append(q[:, sv > 1e-10])
        return np.concatenate(probes, axis=1) if probes else np.empty((h.shape[0], 0))


def block_dictionary_factor_state(
    outputs,
    *,
    groups=12,
    width=3,
    active=2,
    rank=1,
    seed=0,
    fit_iterations=20,
    neighbors=16,
    model=None,
):
    """Fit (or reuse) a BlockDictionary on layer outputs; return factor state.

    Parameters
    ----------
    outputs :
        Sample-major activations ``[N, d_out]`` (torch or NumPy).
    model :
        Optional already-fitted ``BlockDictionary``. When omitted, one is fit on
        ``outputs``.

    Returns
    -------
    bases : torch.Tensor
        ``[M, d_out, r]`` orthonormal(ish) factor tangent bases.
    active_mask : torch.Tensor
        ``[N, M]`` boolean encode support (which factors are active per sample).
    """
    import torch

    if isinstance(outputs, torch.Tensor):
        y = outputs.detach().cpu().float().numpy()
    else:
        y = np.asarray(outputs, dtype=np.float64)
    if y.ndim != 2 or y.shape[0] < 2:
        raise ValueError('outputs must be [N, d] with N >= 2')
    h = y.T
    if model is None:
        if not 1 <= active <= groups:
            raise ValueError('active must lie in [1, groups]')
        if rank > width:
            raise ValueError('rank must be <= block width')
        model = BlockDictionary(groups, width, active, seed=seed).fit(
            h, iterations=fit_iterations
        )
    elif not isinstance(model, BlockDictionary):
        raise TypeError('model must be a fitted BlockDictionary or None')
    bases_np, active_np = model.factor_state(
        h, neighbors=neighbors, rank=rank, seed=seed + 1
    )
    # [d, M, r] -> [M, d, r]; [M, N] -> [N, M]
    bases = torch.from_numpy(np.ascontiguousarray(bases_np.transpose(1, 0, 2))).float()
    active_mask = torch.from_numpy(np.ascontiguousarray(active_np.T)).bool()
    return bases, active_mask



def synthetic(seed=7):
    """Dense embeddings of additive circles; held-out analytic tangent oracle."""
    rng = np.random.default_rng(seed)
    d, m, groups, width = 48, 24, 12, 3
    dictionary = np.concatenate([np.linalg.qr(rng.normal(size=(d,width)))[0]
                                 for _ in range(groups)], axis=1)
    def sample(n):
        z = np.zeros((groups*width,n))
        tangents = []
        for j in range(n):
            for g in rng.choice(groups, 2, replace=False):
                angle = rng.uniform(-np.pi,np.pi)
                z[g*width:g*width+width,j] = [np.cos(angle),np.sin(angle),0.3*np.sin(2*angle)]
                v = dictionary[:,g*width:(g+1)*width]@np.array([-np.sin(angle),np.cos(angle),0.6*np.cos(2*angle)])
                tangents.append(v/np.linalg.norm(v))
        return dictionary@z, np.stack(tangents,axis=1)
    train, _ = sample(480)
    test, tangent_test = sample(240)
    return rng.normal(size=(m,d))/np.sqrt(d), train, test, tangent_test

